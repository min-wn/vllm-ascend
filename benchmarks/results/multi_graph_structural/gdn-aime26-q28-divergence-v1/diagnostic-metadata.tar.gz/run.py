import json,os,pathlib,subprocess,time
root=pathlib.Path('/workspace/gdn-aime26-q28-divergence-v1')
command=['torchrun','--nproc_per_node=2','--master_port=29841',str(root/'tools/multi_graph_gdn_aime26_divergence_probe.py'),'--trace',str(root/'official-trace.json'),'--output',str(root/'common-official')]
env=os.environ.copy()
env.update(ASCEND_RT_VISIBLE_DEVICES='0,1',TASK_QUEUE_ENABLE='0',HCCL_DETERMINISTIC='true',PYTHONPATH=str(root/'tools')+':/workspace/gdn-aime26-v1/tools:'+env.get('PYTHONPATH',''))
(root/'launch.json').write_text(json.dumps(dict(command=command,devices='0,1',pid=os.getpid(),started=time.time(),untimed=True,scope='Q28 first divergence; 151 Q4 steps; no task scoring'),indent=2)+'\n')
result=subprocess.run(command,env=env)
(root/'exit.json').write_text(json.dumps(dict(returncode=result.returncode,ended=time.time()),indent=2)+'\n')
