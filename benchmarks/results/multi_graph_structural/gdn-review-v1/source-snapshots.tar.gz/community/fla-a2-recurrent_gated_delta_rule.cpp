/**
 * Copyright (c) 2025-2026 Tianjin University, Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 */

/*!
 * \file recurrent_gated_delta_rule.cpp
 * \brief
 */
#if defined(__CCE_AICORE__) && __CCE_AICORE__ == 310
#include "arch35/recurrent_gated_delta_rule.h"
#else
#include "recurrent_gated_delta_rule.h"
#endif
#include "recurrent_gated_delta_rule_tiling_data.h"


using namespace AscendC;
using namespace matmul;
using namespace RecurrentGatedDeltaRule;

namespace RecurrentGatedDeltaRule {

template <int D_T>
struct RGDRDTypeTraits;

template <>
struct RGDRDTypeTraits<RGDR_TPL_BF16> {
    using type = bfloat16_t;
};

template <>
struct RGDRDTypeTraits<RGDR_TPL_FP32> {
    using type = float;
};

} // namespace RecurrentGatedDeltaRule

#ifndef TORCH_MODE
template <int D_T_STATE>
__global__ __aicore__ void
recurrent_gated_delta_rule(GM_ADDR query, GM_ADDR key, GM_ADDR value, GM_ADDR beta, GM_ADDR state, GM_ADDR cuSeqlens,
                           GM_ADDR ssmStateIndices, GM_ADDR g, GM_ADDR gk, GM_ADDR numAcceptedTokens, GM_ADDR out,
                           GM_ADDR stateOut, GM_ADDR workspaceGM, GM_ADDR tilingGM)
{
    REGISTER_TILING_DEFAULT(RecurrentGatedDeltaRuleTilingData);
    GET_TILING_DATA(tilingData, tilingGM);
    KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_AIV_ONLY);
    TPipe pipe;
    using StateType = typename RGDRDTypeTraits<D_T_STATE>::type;
    RGDR<bfloat16_t, bfloat16_t, StateType> op(&tilingData);
    RGDRInitParams initParams{query, key, value, g, gk, beta, state, cuSeqlens,
                              ssmStateIndices, numAcceptedTokens, out, stateOut};
    op.Init(initParams, &pipe);
    op.Process();
}
#endif
