# mypy: ignore-errors

import itertools
from typing import Any

import torch
from vllm.config import CacheConfig
from vllm.model_executor.layers.mamba.mamba_utils import MambaStateCopyFunc
from vllm.utils.math_utils import cdiv
from vllm.v1.core.sched.output import SchedulerOutput
from vllm.v1.kv_cache_interface import (
    KVCacheConfig,
    MambaSpec,
    UniformTypeKVCacheSpecs,
)
from vllm.v1.worker import mamba_utils
from vllm.v1.worker.gpu_input_batch import CachedRequestState
from vllm.v1.worker.gpu_input_batch import InputBatch as GPUInputBatch
from vllm.v1.worker.mamba_utils import MambaCopyBuffers

from vllm_ascend.device.hardware_profile import HardwareCapability, get_current_hardware_profile
from vllm_ascend.ops.triton.batch_memcpy import batch_memcpy_kernel
from vllm_ascend.ops.triton.mamba.postprocess import postprocess_mamba_fused_kernel

# Upstream uses 16 temporal-copy tiles to saturate H100/GB200. K3 already
# exposes 138 independent state programs per request, while Triton-Ascend
# flattens all grid dimensions into a coreDim that cannot exceed 65535. Keep
# the pre-tiling launch shape on Ascend: it has enough state-level parallelism
# and remains valid at the configured request limit (for example,
# 32 * 138 * 1 instead of 32 * 138 * 16).
mamba_utils._TEMPORAL_TILES = 1


def _can_launch_triton_batch_memcpy() -> bool:
    return get_current_hardware_profile().supports(HardwareCapability.TRITON_BATCH_MEMCPY)


def _get_state_copy_funcs_for_layer(
    kv_cache_group,
    layer_name: str,
    mamba_state_copy_funcs,
):
    mamba_spec = kv_cache_group.kv_cache_spec
    if isinstance(mamba_spec, UniformTypeKVCacheSpecs):
        mamba_spec = mamba_spec.kv_cache_specs[layer_name]
    assert isinstance(mamba_spec, MambaSpec)
    return mamba_state_copy_funcs[mamba_spec.mamba_type]


def _batch_memcpy_triton(src_ptrs, dst_ptrs, sizes):
    batch = src_ptrs.shape[0]
    assert dst_ptrs.shape[0] == batch
    assert sizes.shape[0] == batch

    grid = (batch,)
    # using larger block_size to accelerate copy.
    BLOCK_SIZE = 8192
    batch_memcpy_kernel[grid](src_ptrs, dst_ptrs, sizes, BLOCK_SIZE=BLOCK_SIZE)


def _stage_mamba_copy_metadata(copy_bufs: mamba_utils.MambaCopyBuffers) -> None:
    """Stage pointer metadata while input-preparation buffers are protected."""
    n = copy_bufs.offset
    if n == 0:
        return
    copy_bufs.src_ptrs.copy_to_gpu(n)
    copy_bufs.dst_ptrs.copy_to_gpu(n)
    copy_bufs.sizes.copy_to_gpu(n)


def _do_mamba_copy_block_npu(copy_bufs: mamba_utils.MambaCopyBuffers) -> None:
    """Copy state after KV load using metadata staged during preprocessing."""
    n = copy_bufs.offset
    if n == 0:
        return
    _batch_memcpy_triton(
        copy_bufs.src_ptrs.gpu[:n],
        copy_bufs.dst_ptrs.gpu[:n],
        copy_bufs.sizes.gpu[:n],
    )


def _tensor_view_from_data_ptr(state: torch.Tensor, start_addr: int, num_elements: int) -> torch.Tensor:
    byte_offset = start_addr - state.data_ptr()
    element_size = state.element_size()
    if byte_offset < 0 or byte_offset % element_size != 0:
        raise RuntimeError("Invalid Mamba state copy pointer.")

    element_offset = byte_offset // element_size
    # MRV2 binds Mamba states as views into block-major pages, so adjacent
    # logical blocks can be separated by page padding. Flatten the underlying
    # storage from this state's first element instead of requiring the logical
    # state tensor itself to be contiguous.
    storage_offset = state.storage_offset()
    storage_numel = state.untyped_storage().nbytes() // element_size
    flat_state = state.as_strided(
        (storage_numel - storage_offset,),
        (1,),
        storage_offset=storage_offset,
    )
    if element_offset + num_elements > flat_state.numel():
        raise RuntimeError("Mamba state copy range exceeds tensor storage.")
    return flat_state.narrow(0, element_offset, num_elements)


def _get_tensor_copy_pairs(copy_bufs: mamba_utils.MambaCopyBuffers) -> list[tuple[torch.Tensor, torch.Tensor]]:
    if copy_bufs.offset == 0 or not hasattr(copy_bufs, "_tensor_copy_pairs"):
        copy_bufs._tensor_copy_pairs = []
    return copy_bufs._tensor_copy_pairs


def _collect_mamba_copy_meta_torch(
    copy_bufs: mamba_utils.MambaCopyBuffers,
    kv_cache_config,
    mamba_state_copy_funcs,
    mamba_group_ids: list[int],
    src_block_idx: int,
    dest_block_idx: int,
    accept_token_bias: int,
    req_state,
    forward_context: dict[str, Any],
) -> None:
    if src_block_idx == dest_block_idx and accept_token_bias == 0:
        return

    tensor_copy_pairs = _get_tensor_copy_pairs(copy_bufs)
    sizes_np = copy_bufs.sizes.np
    offset = copy_bufs.offset

    for mamba_group_id in mamba_group_ids:
        block_ids = req_state.block_ids[mamba_group_id]
        dest_block_id = block_ids[dest_block_idx]
        kv_cache_group = kv_cache_config.kv_cache_groups[mamba_group_id]
        layer_names = kv_cache_group.layer_names
        for layer_name in layer_names:
            attention = forward_context[layer_name]
            kv_caches: list[torch.Tensor] = attention.kv_cache
            state_copy_funcs = _get_state_copy_funcs_for_layer(
                kv_cache_group,
                layer_name,
                mamba_state_copy_funcs,
            )
            for state, state_copy_func in zip(kv_caches, state_copy_funcs):
                copy_spec = state_copy_func(state, block_ids, src_block_idx, accept_token_bias + 1)
                src_state = _tensor_view_from_data_ptr(state, copy_spec.start_addr, copy_spec.num_elements)
                dst_state = _tensor_view_from_data_ptr(state, state[dest_block_id].data_ptr(), copy_spec.num_elements)
                tensor_copy_pairs.append((src_state, dst_state))
                sizes_np[offset] = copy_spec.num_elements * state.element_size()
                offset += 1

    copy_bufs.offset = offset


def _do_mamba_copy_block_torch(copy_bufs: mamba_utils.MambaCopyBuffers):
    n = copy_bufs.offset
    if n == 0:
        if hasattr(copy_bufs, "_tensor_copy_pairs"):
            copy_bufs._tensor_copy_pairs = []
        return

    tensor_copy_pairs = getattr(copy_bufs, "_tensor_copy_pairs", None)
    if tensor_copy_pairs is None or len(tensor_copy_pairs) != n:
        raise RuntimeError("Mamba tensor copy metadata is incomplete.")

    for src_state, dst_state in tensor_copy_pairs:
        dst_state.copy_(src_state.clone())
    copy_bufs._tensor_copy_pairs = []


def _postprocess_mamba_align_gpu_cpu_fallback(
    *,
    bufs: "mamba_utils.MambaBuffers",
    num_reqs: int,
    num_accepted_tokens_gpu: torch.Tensor,
    num_accepted_tokens_cpu_tensor: torch.Tensor,
    input_batch: GPUInputBatch,
    kv_cache_config: KVCacheConfig,
    forward_context: dict[str, Any],
    mamba_state_copy_funcs: dict[str, tuple[MambaStateCopyFunc, ...]],
) -> None:
    """CPU fallback for 310P where the Triton fused postprocess is unavailable."""
    ctx = bufs.postprocess_align
    assert ctx is not None
    assert ctx.mamba_state_idx_buf is not None
    assert ctx.num_scheduled_tokens_buf is not None
    assert ctx.num_computed_tokens_buf is not None
    assert ctx.num_draft_tokens_buf is not None

    # stage_postprocess_inputs_to_gpu has already materialized the same
    # per-request values into the CpuGpuBuffer numpy views. 310P cannot use the
    # Triton fused kernel, so reuse the CPU views to mirror its decision logic.
    mamba_state_idx = ctx.mamba_state_idx_buf.np
    num_scheduled_tokens = ctx.num_scheduled_tokens_buf.np
    num_computed_tokens = ctx.num_computed_tokens_buf.np
    num_draft_tokens = ctx.num_draft_tokens_buf.np
    block_size = ctx.block_size

    # Upstream initializes num_accepted_tokens_out from the real accepted-token
    # counts, then only overwrites entries where src and dest are the same
    # block. Preserve that default so the next preprocess keeps the right
    # accept_token_bias when multiple draft tokens were accepted.
    num_accepted_tokens_cpu_tensor[:num_reqs].copy_(num_accepted_tokens_gpu[:num_reqs])
    # InputBatch rows may be condensed/reused by async scheduling before this
    # fallback consumes the snapshot. Keep this step's accepted counts
    # independent from those mutable request rows.
    num_accepted_tokens = num_accepted_tokens_cpu_tensor
    for i in range(num_reqs):
        num_tokens_running_state = num_computed_tokens[i] + num_scheduled_tokens[i] - num_draft_tokens[i]
        new_num_computed_tokens = num_tokens_running_state + num_accepted_tokens[i] - 1
        aligned_new_computed_tokens = new_num_computed_tokens // block_size * block_size
        if aligned_new_computed_tokens < num_tokens_running_state:
            continue

        src_block_idx = mamba_state_idx[i]
        dest_block_idx = aligned_new_computed_tokens // block_size - 1
        accept_token_bias = aligned_new_computed_tokens - num_tokens_running_state
        if src_block_idx == dest_block_idx:
            # Match the fused kernel: once the running state remains in the
            # same block, the next preprocess should start from token bias 0.
            num_accepted_tokens_cpu_tensor[i] = 1
            if accept_token_bias == 0:
                continue

        # The upstream fused kernel also copies Mamba state in this postprocess
        # step. Do the same with tensor views so 310P avoids Triton without
        # changing where conv/temporal state lands before the next iteration.
        for mamba_group_id in ctx.mamba_group_ids:
            block_ids = input_batch.block_table[mamba_group_id].get_numpy_array()[i]
            dest_block_id = block_ids[dest_block_idx]
            kv_cache_group = kv_cache_config.kv_cache_groups[mamba_group_id]
            layer_names = kv_cache_group.layer_names
            for layer_name in layer_names:
                attention = forward_context[layer_name]
                kv_caches: list[torch.Tensor] = attention.kv_cache
                state_copy_funcs = _get_state_copy_funcs_for_layer(
                    kv_cache_group,
                    layer_name,
                    mamba_state_copy_funcs,
                )
                for state, state_copy_func in zip(kv_caches, state_copy_funcs):
                    copy_spec = state_copy_func(state, block_ids, src_block_idx, accept_token_bias + 1)
                    src_state = _tensor_view_from_data_ptr(state, copy_spec.start_addr, copy_spec.num_elements)
                    dst_state = _tensor_view_from_data_ptr(
                        state, state[dest_block_id].data_ptr(), copy_spec.num_elements
                    )
                    dst_state.copy_(src_state.clone())


def _batch_memcpy_unavailable(src_ptrs, dst_ptrs, sizes):
    raise RuntimeError(
        "Pointer-based Mamba batch memcpy requires Triton and is not available "
        "on 310P. Use the tensor-copy fallback path instead."
    )


def _reset_layerwise_copy_meta(copy_bufs: mamba_utils.MambaCopyBuffers) -> None:
    copy_bufs._layer_copy_metadata = {}
    copy_bufs._layer_copy_slices = {}
    copy_bufs._layer_copy_staged = False
    copy_bufs._layer_tensor_copy_pairs = {}
    copy_bufs._tensor_copy_pairs = []


def _collect_mamba_copy_meta_with_layers(
    copy_bufs: mamba_utils.MambaCopyBuffers,
    kv_cache_config,
    mamba_state_copy_funcs,
    mamba_group_ids: list[int],
    src_block_idx: int,
    dest_block_idx: int,
    accept_token_bias: int,
    req_state,
    forward_context: dict[str, Any],
) -> None:
    """Collect copy metadata grouped per layer (triton pointer path).

    Same iteration order and buffer rows as upstream collect_mamba_copy_meta, but
    records for every layer which rows belong to it so a layerwise KV load can
    consume its slice as soon as that layer finishes loading.
    """
    if src_block_idx == dest_block_idx and accept_token_bias == 0:
        return

    layer_copy_metadata = copy_bufs._layer_copy_metadata
    src_ptrs_np = copy_bufs.src_ptrs.np
    dst_ptrs_np = copy_bufs.dst_ptrs.np
    sizes_np = copy_bufs.sizes.np
    offset = copy_bufs.offset

    for mamba_group_id in mamba_group_ids:
        block_ids = req_state.block_ids[mamba_group_id]
        dest_block_id = block_ids[dest_block_idx]
        kv_cache_group = kv_cache_config.kv_cache_groups[mamba_group_id]
        layer_names = kv_cache_group.layer_names
        for layer_name in layer_names:
            attention = forward_context[layer_name]
            kv_caches: list[torch.Tensor] = attention.kv_cache
            layer_meta = layer_copy_metadata.setdefault(layer_name, ([], [], []))
            state_copy_funcs = _get_state_copy_funcs_for_layer(
                kv_cache_group,
                layer_name,
                mamba_state_copy_funcs,
            )
            for state, state_copy_func in zip(kv_caches, state_copy_funcs):
                copy_spec = state_copy_func(state, block_ids, src_block_idx, accept_token_bias + 1)
                src_ptr = copy_spec.start_addr
                dst_ptr = state[dest_block_id].data_ptr()
                size = copy_spec.num_elements * state.element_size()
                src_ptrs_np[offset] = src_ptr
                dst_ptrs_np[offset] = dst_ptr
                sizes_np[offset] = size
                layer_meta[0].append(src_ptr)
                layer_meta[1].append(dst_ptr)
                layer_meta[2].append(size)
                offset += 1

    copy_bufs.offset = offset


def prepare_mamba_copy_by_layer(copy_bufs: mamba_utils.MambaCopyBuffers) -> None:
    """Stage all layer copy metadata before layerwise model execution.

    ``CpuGpuBuffer.copy_to_gpu`` is non-blocking. Repacking the same pinned CPU
    buffers for every layer can therefore overwrite metadata that an earlier
    H2D copy has not consumed yet. Pack all layers once and keep their GPU
    slices immutable for the duration of the forward pass.
    """
    layer_copy_metadata = getattr(copy_bufs, "_layer_copy_metadata", None)
    if not layer_copy_metadata or getattr(copy_bufs, "_layer_copy_staged", False):
        return

    offset = 0
    layer_copy_slices = {}
    for layer_name, (src_ptrs, dst_ptrs, sizes) in layer_copy_metadata.items():
        num_copies = len(src_ptrs)
        end = offset + num_copies
        copy_bufs.src_ptrs.np[offset:end] = src_ptrs
        copy_bufs.dst_ptrs.np[offset:end] = dst_ptrs
        copy_bufs.sizes.np[offset:end] = sizes
        layer_copy_slices[layer_name] = (offset, end)
        offset = end

    copy_bufs.offset = offset
    copy_bufs._layer_copy_slices = layer_copy_slices
    if offset:
        copy_bufs.src_ptrs.copy_to_gpu(offset)
        copy_bufs.dst_ptrs.copy_to_gpu(offset)
        copy_bufs.sizes.copy_to_gpu(offset)
    copy_bufs._layer_copy_staged = True


def do_mamba_copy_block_for_layer(copy_bufs: mamba_utils.MambaCopyBuffers, layer_name: str) -> None:
    """Copy one layer's running state after its layerwise load completes."""
    layer_copy_metadata = getattr(copy_bufs, "_layer_copy_metadata", None)
    if not layer_copy_metadata:
        return
    metadata = layer_copy_metadata.pop(layer_name, None)
    if metadata is None:
        return
    if not _can_launch_triton_batch_memcpy():
        for src_state, dst_state in copy_bufs._layer_tensor_copy_pairs.pop(layer_name, []):
            dst_state.copy_(src_state.clone())
        return
    layer_slice = copy_bufs._layer_copy_slices.pop(layer_name, None)
    if layer_slice is None:
        return
    start, end = layer_slice
    if start == end:
        return
    _batch_memcpy_triton(
        copy_bufs.src_ptrs.gpu[start:end],
        copy_bufs.dst_ptrs.gpu[start:end],
        copy_bufs.sizes.gpu[start:end],
    )


def finish_mamba_copy_by_layer(copy_bufs: mamba_utils.MambaCopyBuffers) -> None:
    remaining = getattr(copy_bufs, "_layer_copy_metadata", {})
    if remaining:
        raise RuntimeError(f"Mamba state copy was not executed for loaded layers: {sorted(remaining)}")
    copy_bufs._layer_copy_slices = {}
    copy_bufs._layer_copy_staged = False
    copy_bufs._layer_tensor_copy_pairs = {}
    copy_bufs._tensor_copy_pairs = []
    copy_bufs.offset = 0


if _can_launch_triton_batch_memcpy():
    mamba_utils.batch_memcpy_kernel = batch_memcpy_kernel
    mamba_utils.batch_memcpy = _batch_memcpy_triton
    mamba_utils.do_mamba_copy_block = _do_mamba_copy_block_npu
    mamba_utils.postprocess_mamba_fused_kernel = postprocess_mamba_fused_kernel
    # Layerwise KV pool: collect copy metadata grouped per layer so each
    # layer's state copy can run right after its layer load finishes.
    mamba_utils.collect_mamba_copy_meta = _collect_mamba_copy_meta_with_layers
else:
    mamba_utils.batch_memcpy = _batch_memcpy_unavailable
    mamba_utils.collect_mamba_copy_meta = _collect_mamba_copy_meta_torch
    mamba_utils.do_mamba_copy_block = _do_mamba_copy_block_torch
    mamba_utils.postprocess_mamba_align_gpu = _postprocess_mamba_align_gpu_cpu_fallback

# Ascend NPU does not support DT_UINT64 in aclnnInplaceZero.
# MambaCopyBuffers.create() uses torch.uint64 for src_ptrs/dst_ptrs,
# which triggers a runtime error. Remap to int64 at the source.
_original_create = MambaCopyBuffers.create


@classmethod
def _patched_create(cls, max_num_reqs, kv_cache_config, copy_funcs, make_buffer):
    return _original_create(
        max_num_reqs,
        kv_cache_config,
        copy_funcs,
        lambda n, dtype: make_buffer(n, dtype=torch.int64 if dtype == torch.uint64 else dtype),
    )


MambaCopyBuffers.create = _patched_create


def preprocess_mamba(
    scheduler_output: SchedulerOutput,
    kv_cache_config: KVCacheConfig,
    cache_config: CacheConfig,
    mamba_state_idx: dict[str, int],
    input_batch: GPUInputBatch,
    requests: dict[str, CachedRequestState],
    forward_context: dict[str, Any],
    mamba_state_copy_funcs: dict[str, tuple[MambaStateCopyFunc, ...]],
    copy_bufs: MambaCopyBuffers,
):
    """
    Copy the mamba state of previous step to the last
    (1 + num_speculative_blocks) block.
    """
    mamba_group_ids = copy_bufs.mamba_group_ids
    mamba_spec = copy_bufs.mamba_spec
    num_speculative_blocks = mamba_spec.num_speculative_blocks
    # TODO(Chen): we need to optimize this function a lot
    # assert cache_config.enable_prefix_caching
    block_size = mamba_spec.block_size
    finished_req_ids = scheduler_output.finished_req_ids
    preempted_req_ids = scheduler_output.preempted_req_ids or set()
    resumed_req_ids = scheduler_output.scheduled_cached_reqs.resumed_req_ids
    for req_id in itertools.chain(finished_req_ids, preempted_req_ids, resumed_req_ids):
        mamba_state_idx.pop(req_id, None)

    copy_bufs.offset = 0
    _reset_layerwise_copy_meta(copy_bufs)
    for i, req_id in enumerate(input_batch.req_ids):
        req_state = requests[req_id]
        num_scheduled_tokens = scheduler_output.num_scheduled_tokens[req_id]
        if num_scheduled_tokens == 0:
            # Async KV connectors can surface a request in a load-only step
            # before any model tokens are scheduled.  Persisting the derived
            # ``-1`` state index here makes the next real forward skip the
            # copy from the remotely loaded h(N-1) state into its running
            # block.  Re-resolve the index from the updated computed-token
            # count when the request is actually scheduled instead.
            mamba_state_idx.pop(req_id, None)
            continue
        prev_state_idx = mamba_state_idx.get(req_id)
        if prev_state_idx is None:
            # new / resumed request, no previous state
            # if num_computed_tokens is 0, prev_state_idx will be -1
            prev_state_idx = (req_state.num_computed_tokens - 1) // block_size

        num_blocks: int = (
            cdiv(req_state.num_computed_tokens + num_scheduled_tokens, block_size) + num_speculative_blocks
        )

        # We always save the current running state at the last
        # (1 + num_speculative_blocks) block.
        # A corner case worth mention here: assume we have block_size = 4 and
        # num_speculative_tokens = 2. The request is [A, B, C] and contains 2 draft
        # tokens [draft 1, draft 2]. Then we will have:
        # Block 0: [A, B, C, draft 1]
        # Block 1: [draft 2, TOFILL, TOFILL, TOFILL]
        # Block 2: speculative block
        # Block 3: speculative block
        # And use block 1 to save the running state.
        curr_state_idx = num_blocks - 1 - num_speculative_blocks
        mamba_state_idx[req_id] = curr_state_idx
        if prev_state_idx != -1 and prev_state_idx != curr_state_idx:
            mamba_utils.collect_mamba_copy_meta(
                copy_bufs,
                kv_cache_config,
                mamba_state_copy_funcs,
                mamba_group_ids,
                prev_state_idx,
                curr_state_idx,
                input_batch.num_accepted_tokens_cpu[i] - 1,
                req_state,
                forward_context,
            )
            input_batch.num_accepted_tokens_cpu[i] = 1
    if _can_launch_triton_batch_memcpy():
        # Layerwise mode: stage per-layer pointer tables here (same protected
        # input-preparation scope), then each layer's state copy is executed by
        # do_mamba_copy_block_for_layer() right after that layer's KV load
        # finishes. Non-layerwise callers still get the bulk staging below.
        if getattr(copy_bufs, "_layer_copy_metadata", None):
            prepare_mamba_copy_by_layer(copy_bufs)
        else:
            _stage_mamba_copy_metadata(copy_bufs)


mamba_utils.preprocess_mamba = preprocess_mamba

mamba_utils.prepare_mamba_copy_by_layer = prepare_mamba_copy_by_layer
mamba_utils.do_mamba_copy_block_for_layer = do_mamba_copy_block_for_layer
mamba_utils.finish_mamba_copy_by_layer = finish_mamba_copy_by_layer
