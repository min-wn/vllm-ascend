"""Fetch the first frozen formal archive and verify original bytes locally."""

import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import tarfile


workspace = Path(__file__).resolve().parent.parent
evidence = workspace / 'work/vllm-ascend/benchmarks/results/multi_graph_structural/gdn-aime26-v1'
staging = workspace / 'work/aime26-final-download-v1'
staging.mkdir(exist_ok=True)


def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(data)
    return digest.hexdigest()


def fetch(name):
    destination = staging / name
    if destination.exists():
        return destination
    temporary = destination.with_name(destination.name + '.partial')
    subprocess.run([
        'scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=20',
        f'vllm-ascend-030:/workspace/gdn-aime26-v1/{name}', str(temporary),
    ], check=True)
    temporary.replace(destination)
    return destination


identity_path = fetch('formal-evidence-identity.json')
identity = json.loads(identity_path.read_bytes())
archive_path = fetch('formal-evidence.tar.gz')
if archive_path.stat().st_size != identity['bytes'] or sha256(archive_path) != identity['sha256']:
    raise ValueError('formal archive bytes do not match the remote identity')

seen = set()
with tarfile.open(archive_path, 'r:gz') as archive:
    for member in archive:
        relative = PurePosixPath(member.name)
        if relative.is_absolute() or '..' in relative.parts or '\\' in member.name or ':' in member.name:
            raise ValueError(f'unsafe archive path: {member.name}')
        destination = evidence.joinpath(*relative.parts).resolve()
        if not destination.is_relative_to(evidence.resolve()):
            raise ValueError(f'archive path escapes evidence root: {member.name}')
        if member.isdir():
            destination.mkdir(parents=True, exist_ok=True)
            continue
        if not member.isfile() or member.name not in identity['files'] or member.name in seen:
            raise ValueError(f'unexpected, duplicate or nonregular member: {member.name}')
        record = identity['files'][member.name]
        destination.parent.mkdir(parents=True, exist_ok=True)
        if not destination.exists():
            temporary = destination.with_name(destination.name + '.fetch-partial')
            with archive.extractfile(member) as source, temporary.open('wb') as target:
                shutil.copyfileobj(source, target)
            if temporary.stat().st_size != record['bytes'] or sha256(temporary) != record['sha256']:
                raise ValueError(f'member byte identity failed: {member.name}')
            temporary.replace(destination)
        if destination.stat().st_size != record['bytes'] or sha256(destination) != record['sha256']:
            raise ValueError(f'existing evidence has different bytes: {member.name}')
        seen.add(member.name)
if seen != set(identity['files']):
    raise ValueError('archive membership does not match its complete file identity')

for source in (identity_path, archive_path):
    destination = evidence / source.name
    if destination.exists() and sha256(destination) != sha256(source):
        raise ValueError(f'preserve different existing evidence: {destination}')
    if not destination.exists():
        shutil.copyfile(source, destination)

formal = evidence / 'formal'
questions = {v: sorted(p.name for p in formal.glob(f'{v}.question*.json'))
             for v in ('official', 'compact')}
expected_questions = {v: [f'{v}.question{i:02}.json' for i in range(30)]
                      for v in ('official', 'compact')}
group_records = [json.loads(p.read_bytes()) for p in sorted(formal.glob('*.group*.result.json'))]
actual_groups = {(r['variant'], r['group']) for r in group_records}
expected_groups = {(v, i) for v in ('official', 'compact') for i in range(4)}
group_indices_match = all(r['indices'] == list(range(r['group'] * 8, min(30, r['group'] * 8 + 8)))
                          for r in group_records)
verification = dict(
    original_archive_sha256=identity['sha256'], verified_files=len(seen),
    all_original_file_bytes_verified=True,
    all_60_question_files_present=questions == expected_questions,
    all_eight_distinct_groups_present=actual_groups == expected_groups and len(group_records) == 8,
    all_group_indices_match=group_indices_match,
    question_counts={v: len(rows) for v, rows in questions.items()},
)
(evidence / 'local-archive-verification.json').write_text(
    json.dumps(verification, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(verification))
