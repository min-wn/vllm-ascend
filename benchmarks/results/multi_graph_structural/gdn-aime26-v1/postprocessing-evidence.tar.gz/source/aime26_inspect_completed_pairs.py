"""Inspect frozen completed outputs without changing any generation job."""

import argparse
import hashlib
import json
from pathlib import Path
import sys

workspace = Path(__file__).resolve().parent.parent
parser = argparse.ArgumentParser()
parser.add_argument('--min-index', type=int, default=0)
parser.add_argument('--output', type=Path, default=workspace / 'work/aime26-partial-review-draft.json')
args = parser.parse_args()
repo = workspace / 'work/vllm-ascend'
sys.path.insert(0, str(repo / 'benchmarks'))
from multi_graph_gdn_aime26 import load_evalscope_rules, score_output

evidence = repo / 'benchmarks/results/multi_graph_structural/gdn-aime26-v1'
generations = workspace / 'work/aime26-partial-generations'
targets = json.loads((evidence / 'inputs/targets.json').read_bytes())
rules = load_evalscope_rules(evidence / 'evalscope-source')
records = []
for target in targets:
    index = target['index']
    if index < args.min_index:
        continue
    paths = {v: generations / f'{v}.question{index:02}.json' for v in ('official', 'compact')}
    if not all(path.exists() for path in paths.values()):
        continue
    row = dict(index=index, id=target['id'], target=target['target'])
    for variant, path in paths.items():
        raw = path.read_bytes()
        generation = json.loads(raw)
        try:
            score = score_output(rules, generation['scorer_text'], str(target['target']))
        except rules['MathEvaluationError'] as error:
            score = dict(matched=False, prediction_valid=False, reference_valid=True,
                         extracted='', reason='scoring_error', scoring_error=repr(error))
        row[variant] = dict(
            score=score, output_sha256=hashlib.sha256(raw).hexdigest(),
            tokens=generation['generated_token_count'], finish_reason=generation['finish_reason'],
            final_raw_excerpt=generation['raw_output'][-2200:],
        )
    row['answer_changed'] = row['official']['score']['extracted'] != row['compact']['score']['extracted']
    records.append(row)

result = dict(purpose='working review of completed outputs, not the final 30-pair score report', rows=records)
args.output.write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(completed_pairs=len(records), answer_changes=sum(r['answer_changed'] for r in records))))
for row in records:
    if row['answer_changed']:
        shown = json.loads(json.dumps(row))
        for variant in ('official', 'compact'):
            score = shown[variant]['score']
            extracted = score.get('extracted', '')
            score.pop('extracted', None)
            score.pop('filtered_prediction', None)
            score.update(extracted_length=len(extracted), extracted_prefix=extracted[:120])
        print(json.dumps(shown, ensure_ascii=False, indent=2))
