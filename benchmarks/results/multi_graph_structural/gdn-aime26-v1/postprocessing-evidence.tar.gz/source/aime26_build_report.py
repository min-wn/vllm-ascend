"""Render the closed, single-run paired evaluation after scoring and review."""

import argparse
import json
from pathlib import Path
import statistics


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--workspace', type=Path, required=True)
workspace = parser.parse_args().workspace.resolve()
repo = workspace / 'work/vllm-ascend'
evidence = repo / 'benchmarks/results/multi_graph_structural/gdn-aime26-v1'
scores = json.loads((evidence / 'paired-scores.json').read_bytes())
audit = json.loads((evidence / 'continuous-generation-audit.json').read_bytes())
closeout = json.loads((evidence / 'formal-closeout-verification.json').read_bytes())
reviews = json.loads((evidence / 'answer-change-review.json').read_bytes())
summary = scores['summary']
rows = scores['rows']
changed = [row for row in rows if row['answer_changed']]
if {row['index'] for row in changed} != {row['index'] for row in reviews['rows']}:
    raise ValueError('every changed extracted answer requires an explicit review')
if not reviews['completed']:
    raise ValueError('do not publish unfinished answer checks')
if [r['id'] for r in rows if r['official']['correct'] and not r['compact']['correct']] != [14, 23, 28]:
    raise ValueError('the inspected final task observations must match this report')
if [r['id'] for r in rows if not r['official']['correct'] and not r['compact']['correct']] != [9, 15, 24, 30]:
    raise ValueError('the inspected final both-wrong observations changed')


def cell(value):
    value = str(value).replace('|', r'\|').replace('\n', ' ')
    if len(value) > 180:
        return value[:80] + f'…（共 {len(value):,} 字符，完整值见 JSON）…' + value[-20:]
    return value


def table(headers, data):
    lines = ['| ' + ' | '.join(headers) + ' |', '| ' + ' | '.join(['---'] * len(headers)) + ' |']
    lines.extend('| ' + ' | '.join(cell(item) for item in row) + ' |' for row in data)
    return '\n'.join(lines)


def finish(row):
    return {'eos': 'EOS', 'length': '长度上限', 'runtime_error': '运行失败'}.get(row['finish_reason'], row['finish_reason'])


def answer(row):
    return row['extracted'] or '解析失败'


def yes(value):
    return '正确' if value else '错误'


official, compact = summary['official'], summary['compact']
delta = (compact['accuracy'] - official['accuracy']) * 100
complete = scores['actual_generation_complete_all']
parts = [
    '# GDN AIME26 一次实际生成配对评测结果',
    f"官方 {official['correct']}/30（{official['accuracy']:.2%}），compact FP32 ready "
    f"{compact['correct']}/30（{compact['accuracy']:.2%}），差值 {delta:+.2f} 个百分点。"
    f"两侧均正确 {summary['both_correct']} 题、均错误 {summary['both_wrong']} 题、"
    f"官方独对 {summary['official_only']} 题、compact 独对 {summary['compact_only']} 题。",
    f"本轮全部 60 次实际生成是否均按冻结停止条件完成并留下输出：{'是' if complete else '否'}。"
    '这里包括触及长度上限的终止，不等于所有解答均完整。'
    '这是固定配置下 30 题、每题每侧一次的任务观察，不足以证明普遍无损或生产可用。'
    '原分布初筛失败和局部退化继续有效。',
    '本次官方独对的题为第 14、23、28 题。第 14、23 题中，官方正常结束并答对，'
    'compact 在 81,920 token 上限处截断且未完成解答；第 28 题两侧均正常结束，'
    '官方给出正确答案 107，compact 给出错误答案 115。'
    '因此，在本轮固定配置中已观察到实际任务退化，现有证据不足以认定这些数值差异已经可接受。'
    '两侧均错的题为第 9、15、24、30 题；其余 23 题均答对。',
    '## 冻结的对象与设置',
    '模型为原 Qwen3.5-27B、TP2，BF16 权重和激活、FP32 SSM、HF32 关闭；'
    '官方和 compact 的状态算法、Q4 内核和权重保持冻结。304 个 decoder 投影共同使用 NZ29，'
    'LM head 使用同一官方实现。质量入口采用 eager 执行，不能外推为长上下文 ACLGraph 服务资格。',
    '本文“官方”指同一离线 Q4 生成适配器中的官方 dense recurrence 对照。'
    '两侧均独立生成，没有使用普通官方服务得分或 teacher-forcing 结果替代 compact 任务评测。',
    '使用 ModelScope `evalscope/aime26` 全部 30 题，revision '
    '`12ae93b463353acd4d272dbbc7dbecbcfb902642`，数据 SHA256 为 '
    '`52822957957a3f577d1e9706c36a66a8108a3f99b6aff424cfb72dff0094a9ee`。'
    '工具固定为 EvalScope 1.13.0、AIME adapter evaluation_version v1.1、Math-Verify 0.9.0。'
    '逐字使用该版本 AIME prompt、checkpoint 聊天模板，enable_thinking=True。',
    '查看正式输出前固定 greedy（temperature=0、top_p=1、top_k 禁用、penalty 中性）、seed=42，'
    '每题最多 81,920 个输出 token，max_model_len=82,944；EOS=[248046,248044]，'
    '无文本 stop，不因 boxed 答案提前停止。模型卡推荐采样但未禁止 greedy；'
    '本轮使用 greedy 减少采样变化，不用于复现模型卡成绩。',
    '固定按题序分成 8/8/8/6 四组，两侧分别从零状态完成相同 prompt 的 prefill。'
    '各侧只依据自身历史用安装版 vLLM ngram proposer 给出最多 3 个候选，'
    '由 Q4 logits 的 argmax 顺序验证，使用真实接受前缀推进 conv、SSM、KV。'
    '未提出的填充 token 不能被接受，EOS/预算可在接受前缀内部结束。'
    '终末提交选择每个请求的最后实际接受数；末输出 token 保留普通 decode 的尚未计算语义。'
    '生成 manifest 不含参考答案，参考答案仅进入离线评分器。',
    '## 实际路径与连续状态审计',
    f"独立审计是否通过：{'是' if audit.get('passed') else '否'}。"
    '审计根据逐步日志独立重建本侧历史、最早最长 ngram、候选验证、接受长度、'
    'owner、位置、输出 token 全序列和终末选择。这是生成与状态生命周期契约审计，'
    '不代表两种算法的浮点状态逐位相等。每步检查全部 48 个 GDN 层实际调用；'
    '两个 TP rank 都在各自进程中执行该计数断言，持久化日志由 rank0 写出。'
    '表中调用数为逻辑层入口累计值（48×整网步数），不再乘 TP2，亦非所有设备内部 kernel launch 数。'
    '未知 handle 或非 Q4 路径直接报错。共同的官方 prefill 单列，不算 compact decode 回退。',
]

if audit.get('groups'):
    parts.append(table(
        ['版本', '组（题号）', 'Q4 整网步数', 'GDN Q4 调用数', '实际接受数 1/2/3/4 的次数'],
        [[g['variant'], f"{g['group']}（{g['group'] * 8 + 1}–{min(30, g['group'] * 8 + 8)}）",
          g['steps'], g['q4_calls'], '/'.join(str(g['accepted_counts'].get(str(i), g['accepted_counts'].get(i, 0)))
                                                for i in range(1, 5))]
         for g in audit['groups']],
    ))

maximum = max((g['maximum_position'] for g in closeout['groups'].values()), default=0)
parts.extend([
    f'实际生成访问的最高位置为 {maximum:,}。正式运行前已按 82,944 容量预留互不别名的 KV 页，'
    '并在最高预留位置执行 FIA 及完整 decoder/LM head 有限性检查。'
    '容量探针仅说明地址和执行可达，实际长轨迹的范围以本轮记录为准。'
    '接入阶段 q1–q3 的失败和 q4–q5 的通过证据全部保留于 qualification-evidence.tar.gz。',
    f"运行后源码哈希保持一致：{closeout['all_runtime_sources_unchanged']}；"
    f"native/runtime 二进制哈希保持一致：{closeout['all_binaries_unchanged']}；"
    f"权重文件尺寸和 mtime 与完整运行前哈希记录对应一致：{closeout['all_weight_stats_unchanged']}。"
    '实际生成依赖的 9 个本地辅助源码均与冻结 Git blob 一致；'
    '另有三个未参与生成的旧工具差异已记录，不能称整个 tools 目录与 HEAD 一致。',
    '## 规则评分与逐题结果',
    'EvalScope 在线文档列有 LLM judge；本轮按用户要求固定使用 '
    '[EvalScope AIME26](https://evalscope.readthedocs.io/en/latest/benchmarks/aime26.html) '
    '对应冻结版本源码中的规则分支 `extract_answer` → '
    '`compare_answers(..., integer_only=True)`，不调用 judge。'
    '原始 special-token 输出、完整 token ID 和 skip_special_tokens=True 的评分文本全部保存，'
    '不删除思考、不改写答案。运行失败、解析失败和评分异常计错，全部 30 题保持分母；'
    '截断继续按同一规则评分并单列。'
    '本轮五个整数格式拒绝均发生在长度截断样本：官方第 24、30 题，compact 第 14、23、24 题；'
    '这些样本均未完成解答，全部计入错误和 30 题分母。'
    '表中超长抽取值仅缩略显示，完整抽取值保存在 paired-scores.json。'
    '数据 id 为 1–30，下表题号直接对应冻结数据顺序。',
    table(
        ['项目', '官方', 'compact FP32 ready'],
        [['正常 EOS 结束', *[sum(r[v]['finish_reason'] == 'eos' for r in rows)
                         for v in ('official', 'compact')]]]
        + [[name, official[key], compact[key]] for name, key in (
            ('正确题数', 'correct'), ('触及长度上限', 'length_limited'),
            ('运行失败', 'runtime_failures'), ('解析失败', 'parse_failures'), ('回退调用', 'fallback_calls'))]
        + [['评分异常', *[sum(r[v].get('reason') == 'scoring_error' for r in rows)
                         for v in ('official', 'compact')]]]
        + [['抽取结果违反整数格式', *[sum(r[v].get('reason') == 'integer_literal_required' for r in rows)
                                      for v in ('official', 'compact')]]],
    ),
    table(
        ['题号', '参考', '官方抽取', '官方评分', '官方 token', '官方结束',
         'compact 抽取', 'compact 评分', 'compact token', 'compact 结束'],
        [[r['id'], r['target'], answer(r['official']), yes(r['official']['correct']),
          r['official']['generated_token_count'], finish(r['official']), answer(r['compact']),
          yes(r['compact']['correct']), r['compact']['generated_token_count'], finish(r['compact'])]
         for r in rows],
    ),
])

for variant, label in [('official', '官方'), ('compact', 'compact')]:
    counts = [r[variant]['generated_token_count'] for r in rows]
    parts.append(f'{label} 生成长度：最短 {min(counts):,}，中位数 {statistics.median(counts):,.1f}，'
                 f'最长 {max(counts):,}，合计 {sum(counts):,} token。长度不同来自各自连续生成；'
                 '本轮不据此报告性能变化。')

parts.append('## 答案变化复核')
if not changed:
    parts.append('两侧抽取答案没有变化；所有题仍按同一冻结规则评分，完整输出保留。')
else:
    parts.append('逐项对照原始输出中的最终答案、规则抽取和数据参考值，'
                 '以下记录只核对评分对应关系，不重新求解整份数学证明，也不手工改分。'
                 '完整复核和输出摘录保存于 answer-change-review.json。')
    parts.append(table(
        ['题号', '官方 → compact', '对错变化', '复核结论'],
        [[r['id'], r['official_extracted'] + ' → ' + r['compact_extracted'],
          r['paired_outcome'], r['conclusion']] for r in reviews['rows']],
    ))

parts.extend([
    '## 与原证据并列的结论和边界',
    '原 hidden NRMSE≤0.005 检查失败仍保留。FP32 首步诊断中，起点与 owner/状态映射一致，'
    'layer0 recurrence 约 2e-6 局部差异经后续 BF16 运算放大，最终 hidden NRMSE 为 '
    '0.0118161；未找到可作有限修复的明确实现错误。FP16 排查保持结束。',
    '原真实文本初筛仍失败：平均 KL=0.00556279（门槛 0.001），TV P99=0.05123891'
    '（门槛 0.05），worst-owner ΔNLL=0.12216764（门槛 0.05），'
    '该 owner 局部 PPL 增加 12.99435%；整体 PPL 仅增加 0.0113772% 不覆盖这些失败。',
    '已有同算法 ready/delayed 状态一致性和闭合耗时均值改善 4.801135% 作为旧证据保留。'
    '该计时仅覆盖 decoder+finalnorm，不含 LM head、采样或服务，也不属于多图独有收益。'
    '固定轨迹的该项改善不等于自主生成任务总耗时改善。'
    '本轮不增加性能轮次。',
    f"本轮仅可陈述：在该固定 AIME26 配置下，compact 的净题数变化为 "
    f"{compact['correct'] - official['correct']:+d}，官方独对 {summary['official_only']} 题，"
    f"compact 独对 {summary['compact_only']} 题。30 题的一次配对对小幅任务差异约束很弱，"
    '没有重复采样或其他任务证据，不能据此把误差认定为普遍可接受。'
    '任务观察与原分布/局部退化分别成立。本轮到此收口，不增加轮次或调整解码搜索。',
    '## 工具检查记录',
    '实现阶段已完成 14 项 CPU 单元测试、固定 EvalScope 规则的 7 项样例核对，'
    '新增生成/评分/审计源码的 Ruff 检查通过。正式运行前 q5 的 8/6 请求组接入、'
    '逐步退出、终末提交与最高位置容量检查两侧通过。'
    '仓库整体 `bash format.sh ci` 在既有 CRLF 行尾处解析失败，未声明全仓格式检查通过。'
    '这些工具检查与真实 30 题任务结果分别记录；本轮未增加性能轮次。',
    '## 可复查文件',
    '- `paired-scores.json`：全部 30 对规则评分，含缺失/异常分母。\n'
    '- `continuous-generation-audit.json`：连续状态及真实接受决策独立审计。\n'
    '- `answer-change-review.json`：所有抽取答案变化题的逐项复核。\n'
    '- `formal/`：本地已展开的 60 个逐题原输出、8 组步进日志和生命周期结果；远端仓库中由下列压缩归档保存原始字节。\n'
    '- `formal-evidence.tar.gz`、`formal-evidence-identity.json`：正式证据和逐文件哈希。\n'
    '- `qualification-evidence.tar.gz`：全部接入失败/通过记录与实际运行源码。\n'
    '- `postprocessing-evidence.tar.gz`：本轮归档、报告和人工复核工具及标明未完成的历史工作快照。\n'
    '- `completion-verification.json`：闭合检查、正式产物哈希和格式检查边界。\n'
    '- `freeze/`、`inputs/`、`evalscope-source/`：预冻结协议、权重/二进制身份、数据和评分规则。',
])

text = '\n\n'.join(parts) + '\n'
(evidence / 'report.md').write_text(text, encoding='utf-8', newline='\n')
canonical = repo / 'docs/source/developer_guide/Design_Documents/aclgraph_gdn_aime26_result_zh.md'
canonical.write_text(text, encoding='utf-8', newline='\n')
for name, encoding in [('GDN_AIME26_RESULT_ZH.md', 'utf-8'), ('GDN_AIME26_RESULT_ZH.txt', 'utf-8-sig')]:
    (workspace / name).write_text(text, encoding=encoding, newline='\n')
print(json.dumps(dict(summary=summary, report=str(canonical), bytes=canonical.stat().st_size), ensure_ascii=False))
