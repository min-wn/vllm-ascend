"""Preserve the inspected question-30 pair without altering frozen scoring."""

import json
from pathlib import Path

workspace = Path(__file__).resolve().parent.parent
base = json.loads((workspace / 'work/aime26-answer-change-review.partial-v2.json').read_bytes())
draft = json.loads((workspace / 'work/aime26-finalgroup-review-draft-v2.json').read_bytes())
row = next(r for r in draft['rows'] if r['index'] == 29)
if (row['target'] != 393 or not row['answer_changed']
        or row['official']['finish_reason'] != 'length'
        or row['official']['score']['reason'] != 'integer_literal_required'
        or row['compact']['finish_reason'] != 'eos'
        or row['compact']['score']['extracted'] != '561'
        or row['compact']['score']['matched']):
    raise AssertionError('inspected question-30 evidence differs')

base['rows'].append(dict(
    index=29, id=30, target=393,
    official_extracted=row['official']['score']['extracted'],
    compact_extracted=row['compact']['score']['extracted'],
    paired_outcome='两侧均错误（官方截断，compact 完整答错）',
    conclusion='官方在重复核查中间量时耗尽 81920 token，全输出无 boxed；'
               '抽取到符号等式，以 integer_literal_required 判错。compact 在 36092 token '
               '正常 EOS 结束，原文最终明确给出 boxed 561；抽取与原文一致，但不等于冻结参考 393。'
               '前者为未完成解答的截断，后者为完整解答的答案错误；没有手工改分。',
    output_sha256={v: row[v]['output_sha256'] for v in ('official', 'compact')},
    original_output_excerpts={v: row[v]['final_raw_excerpt'] for v in ('official', 'compact')},
    manual_review='original output endings, boxed answer, rule extraction and frozen reference checked',
))
base['scope'] = 'six inspected changes among 29 completed pairs; not the final 30-pair report'
destination = workspace / 'work/aime26-answer-change-review.partial-v3.json'
if destination.exists():
    raise FileExistsError('preserve the first question-30 review')
destination.write_text(json.dumps(base, ensure_ascii=False, indent=2) + '\n',
                       encoding='utf-8', newline='\n')
print(json.dumps(dict(rows=len(base['rows']), completed=False)))
