"""Preserve completed AIME26 evidence; never launch or rescore generation."""

import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import time

workspace = Path(__file__).resolve().parent.parent
repo = workspace / 'work/vllm-ascend'
evidence = repo / 'benchmarks/results/multi_graph_structural/gdn-aime26-v1'


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def read(name):
    return json.loads((evidence / name).read_bytes())


scores = read('paired-scores.json')
audit = read('continuous-generation-audit.json')
reviews = read('answer-change-review.json')
closeout = read('formal-closeout-verification.json')
identity = read('formal-evidence-identity.json')
archive = evidence / 'formal-evidence.tar.gz'
if archive.stat().st_size != identity['bytes'] or digest(archive) != identity['sha256']:
    raise AssertionError('original formal archive changed')
for name, expected in identity['files'].items():
    path = evidence / name
    if path.stat().st_size != expected['bytes'] or digest(path) != expected['sha256']:
        raise AssertionError(f'original formal bytes changed: {name}')
checks = dict(
    all_60_generations_completed=scores['actual_generation_complete_all'],
    all_30_question_indices_present=[r['index'] for r in scores['rows']] == list(range(30)),
    all_eight_continuous_generation_audits_passed=audit['passed'] and len(audit['groups']) == 8,
    all_seven_answer_changes_reviewed=reviews['completed'] and len(reviews['rows']) == 7,
    review_references_exact_score_bytes=reviews['formal_scores_sha256'] == digest(evidence / 'paired-scores.json'),
    all_formal_original_file_bytes_unchanged=True,
    all_four_generation_exit_codes_zero=len(closeout['exits']) == 4
        and all(r['returncode'] == 0 for r in closeout['exits'].values()),
    frozen_runtime_sources_unchanged=closeout['all_runtime_sources_unchanged'],
    frozen_native_and_runtime_binaries_unchanged=closeout['all_binaries_unchanged'],
    weight_sizes_and_mtimes_unchanged=closeout['all_weight_stats_unchanged'],
    all_frozen_manifest_checks_passed=all(closeout['manifest_checks'].values()),
    zero_fallbacks_and_runtime_failures=all(
        r[v]['fallback_calls'] == 0 and r[v]['finish_reason'] != 'runtime_error'
        for r in scores['rows'] for v in ('official', 'compact')),
)
if not all(checks.values()):
    raise AssertionError(checks)

log = evidence / 'format-ci.log'
if log.exists():
    raise FileExistsError('preserve the first captured Git Bash format log')
format_result = subprocess.run(
    ['D:/Program Files/Git/bin/bash.exe', 'format.sh', 'ci'], cwd=repo,
    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)
log.write_bytes(format_result.stdout)

timestamp = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
status = workspace / 'AIME26_CURRENT_STATUS_ZH.md'
previous = status.read_text(encoding='utf-8')
prefix = (
    '# AIME26 已完成（此前进行中快照在下方保留）\n\n'
    f'闭合记录 UTC：{timestamp}。全部 60 次生成完成，8 组连续状态审计通过。\n'
    '官方 26/30（86.67%），compact 23/30（76.67%）；均对 23、均错 4、官方独对 3、compact 独对 0。\n'
    '官方第 14、23、28 题独对：compact 前两题截断，第 28 题完整答错。\n'
    '官方/compact 分别有 2/3 题触及长度上限；运行失败、解析异常、评分异常、回退均为 0。\n'
    '完整中文报告见同目录 GDN_AIME26_RESULT_ZH.md 或带 UTF-8 BOM 的 GDN_AIME26_RESULT_ZH.txt。\n'
    '原分布初筛失败和局部退化仍有效。本轮收口，不增加重生成、配置搜索或性能轮次。\n\n'
    '---\n\n'
)
status.write_text(prefix + previous, encoding='utf-8', newline='\n')
(workspace / 'AIME26_CURRENT_STATUS_ZH.txt').write_text(
    prefix + previous, encoding='utf-8-sig', newline='\n')

source_names = [
    'aime26_collect_final_remote.py', 'aime26_fetch_final.py', 'aime26_build_report.py',
    'aime26_inspect_completed_pairs.py', 'aime26_record_q30_review.py',
    'aime26_complete_reviews.py', 'aime26_close_local.py',
]
review_names = [
    'aime26-answer-change-review.partial.json', 'aime26-answer-change-review.partial-v2.json',
    'aime26-answer-change-review.partial-v3.json', 'aime26-finalgroup-review-draft.json',
    'aime26-finalgroup-review-draft-v2.json', 'aime26-official24-cap-review.json',
    'aime26-official30-cap-review.json', 'aime26-compact14-cap-review.json',
    'aime26-compact23-cap-review.json', 'aime26-compact24-cap-review.json',
    'aime26-cap-format-audit.json', 'aime26-progress-0821.json',
]
members = {f'source/{name}': workspace / 'work' / name for name in source_names}
members.update({f'working-reviews/{name}': workspace / 'work' / name for name in review_names})
members['root-snapshots/AIME26_CURRENT_STATUS_ZH.md'] = status
post_archive = evidence / 'postprocessing-evidence.tar.gz'
if post_archive.exists():
    raise FileExistsError('preserve the first postprocessing archive')
note = (
    '# AIME26 后处理证据\n\n'
    'source/ 保存工作区 work/ 下使用的后处理源码，脚本按原目录结构运行；不属于被冻结的模型执行实现。\n'
    'working-reviews/ 是带有未完成标记的历史工作复核，仅作过程证据。\n'
    '正式结论以同级 paired-scores.json、continuous-generation-audit.json、'
    'answer-change-review.json 和 report.md 为准。\n'
    '首份 formal-evidence.tar.gz 保存全部原始生成和步进日志；本归档没有启动或重新生成任何题。\n'
).encode('utf-8')
with tarfile.open(post_archive, 'w:gz') as stream:
    info = tarfile.TarInfo('README_ZH.md')
    info.size = len(note)
    stream.addfile(info, io.BytesIO(note))
    for name, path in sorted(members.items()):
        stream.add(path, arcname=name)
post_identity = dict(
    bytes=post_archive.stat().st_size, sha256=digest(post_archive),
    files={name: dict(bytes=path.stat().st_size, sha256=digest(path))
           for name, path in members.items()},
    readme=dict(bytes=len(note), sha256=hashlib.sha256(note).hexdigest()),
)
(evidence / 'postprocessing-evidence-identity.json').write_text(
    json.dumps(post_identity, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

final_names = [
    'paired-scores.json', 'continuous-generation-audit.json', 'answer-change-review.json',
    'formal-evidence.tar.gz', 'formal-evidence-identity.json', 'formal-closeout-verification.json',
    'local-archive-verification.json', 'report.md', 'postprocessing-evidence.tar.gz',
    'postprocessing-evidence-identity.json', 'format-ci.log',
]
record = dict(
    completed_utc=timestamp, closed=True,
    scope='30 questions; one actual generation per variant; no repeats or configuration search',
    frozen_implementation_commit='7ac64e568', manifest_sha256=scores['manifest_sha256'],
    checks=checks, summary=scores['summary'],
    formal_archive_files_verified=len(identity['files']),
    format_check=dict(command='Git Bash: bash format.sh ci', returncode=format_result.returncode,
                      passed=format_result.returncode == 0,
                      note='pre-existing CRLF shell parsing failure; no whole-repository format pass claimed'),
    final_artifacts={name: dict(bytes=(evidence / name).stat().st_size, sha256=digest(evidence / name))
                     for name in final_names},
    old_numeric_and_realtext_screen_failures_preserved=True,
    no_new_performance_claim=True,
)
(evidence / 'completion-verification.json').write_text(
    json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(dict(closed=True, checks=checks, formal_archive_sha256=identity['sha256'],
                      format_returncode=format_result.returncode,
                      postprocessing_archive_bytes=post_identity['bytes']), ensure_ascii=False))
