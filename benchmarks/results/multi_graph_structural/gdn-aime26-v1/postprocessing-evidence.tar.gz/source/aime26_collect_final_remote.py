"""Read-only closeout of the already launched frozen generation experiment."""

import hashlib
import json
from pathlib import Path
import tarfile
import time


root = Path('/workspace/gdn-aime26-v1')
exit_names = [f'formal.{variant}.shard{shard}.exit.json'
              for variant in ('official', 'compact') for shard in (0, 1)]
if any(not (root / name).exists() for name in exit_names):
    raise RuntimeError('existing generation is still running; do not relaunch')

destination = root / 'formal-evidence.tar.gz'
if destination.exists():
    raise FileExistsError('preserve the first formal evidence archive')

frozen_sources = json.loads((root / 'formal.source-sha256.json').read_bytes())
source_checks = {
    name: hashlib.sha256((root / 'tools' / name).read_bytes()).hexdigest() == expected
    for name, expected in frozen_sources.items()
}
binaries = json.loads((root / 'runtime-binaries.json').read_bytes())
binary_checks = {
    name: hashlib.sha256(Path(name).read_bytes()).hexdigest() == record['sha256']
    for name, record in binaries.items()
}
weights = json.loads((root / 'weight-sha256.json').read_bytes())
weight_stat_checks = {}
for name, record in weights.items():
    actual = (Path('/models/Qwen3.5-27B-original') / name).stat()
    weight_stat_checks[name] = (actual.st_size == record['bytes']
                                and actual.st_mtime_ns == record['mtime_ns'])

exits = {name: json.loads((root / name).read_bytes()) for name in exit_names}
manifest = json.loads((root / 'manifest.json').read_bytes())
payload_hash = hashlib.sha256(json.dumps(
    manifest['payload'], sort_keys=True, ensure_ascii=False,
    separators=(',', ':')).encode()).hexdigest()
manifest_checks = {
    'payload_hash_valid': payload_hash == manifest['payload_sha256'],
    'protocol_unchanged': hashlib.sha256((root / 'protocol.md').read_bytes()).hexdigest()
                           == manifest['payload']['protocol_sha256'],
}
for name in exit_names:
    launch = json.loads((root / name.replace('.exit.json', '.launch.json')).read_bytes())
    manifest_checks[name] = launch['manifest_sha256'] == manifest['payload_sha256']
generations = {}
groups = {}
for path in sorted((root / 'formal').glob('*.question*.json')):
    row = json.loads(path.read_bytes())
    generations[path.name] = {key: row[key] for key in (
        'index', 'variant', 'finish_reason', 'generated_token_count', 'fallback_calls')}
for path in sorted((root / 'formal').glob('*.group*.result.json')):
    row = json.loads(path.read_bytes())
    groups[path.name] = {key: row[key] for key in (
        'variant', 'group', 'status', 'steps', 'maximum_position', 'fallback_calls')}

verification = dict(
    collected_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    exits=exits, generations=generations, groups=groups,
    source_checks=source_checks, binary_checks=binary_checks,
    weight_stat_checks=weight_stat_checks, manifest_checks=manifest_checks,
    manifest_sha256=manifest['payload_sha256'],
    all_runtime_sources_unchanged=all(source_checks.values()),
    all_binaries_unchanged=all(binary_checks.values()),
    all_weight_stats_unchanged=all(weight_stat_checks.values()),
    weight_hashes_note='full prelaunch hashes preserved; size/mtime checked after generation',
)
(root / 'formal-closeout-verification.json').write_text(
    json.dumps(verification, indent=2) + '\n', encoding='utf-8')
members = [path for path in sorted(root.iterdir())
           if path.name.startswith('formal') and path.name != destination.name]
with tarfile.open(destination, 'w:gz') as archive:
    for path in members:
        archive.add(path, arcname=path.name,
                    filter=lambda info: None if '__pycache__' in info.name else info)

archive_identity = dict(
    path=str(destination), bytes=destination.stat().st_size,
    sha256=hashlib.sha256(destination.read_bytes()).hexdigest(),
    files={
        str(path.relative_to(root)): dict(
            bytes=path.stat().st_size,
            sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        for parent in members
        for path in (sorted(parent.rglob('*')) if parent.is_dir() else [parent])
        if path.is_file() and '__pycache__' not in path.parts
    },
)
(root / 'formal-evidence-identity.json').write_text(
    json.dumps(archive_identity, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(
    archive={key: value for key, value in archive_identity.items() if key != 'files'},
    exits=exits, outputs=len(generations), groups=len(groups),
    frozen_sources_unchanged=verification['all_runtime_sources_unchanged'],
    binaries_unchanged=verification['all_binaries_unchanged'],
    weight_stats_unchanged=verification['all_weight_stats_unchanged'],
)))
