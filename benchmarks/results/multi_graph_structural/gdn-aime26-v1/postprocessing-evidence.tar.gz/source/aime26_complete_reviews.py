"""Close the seven manually inspected answer changes against formal scores."""

import hashlib
import json
from pathlib import Path

workspace = Path(__file__).resolve().parent.parent
evidence = workspace / 'work/vllm-ascend/benchmarks/results/multi_graph_structural/gdn-aime26-v1'
scores = json.loads((evidence / 'paired-scores.json').read_bytes())
review = json.loads((workspace / 'work/aime26-answer-change-review.partial-v3.json').read_bytes())
row = next(r for r in scores['rows'] if r['index'] == 27)
if (str(row['target']) != '107' or row['official']['extracted'] != '107'
        or row['compact']['extracted'] != '115' or not row['official']['correct']
        or row['compact']['correct']
        or any(row[v]['finish_reason'] != 'eos' for v in ('official', 'compact'))):
    raise AssertionError('inspected question-28 evidence differs')

paths = {v: evidence / f'formal/{v}.question27.json' for v in ('official', 'compact')}
review['rows'].append(dict(
    index=27, id=28, target=107,
    official_extracted='107', compact_extracted='115',
    paired_outcome='官方正确 → compact 错误（均完整结束）',
    conclusion='两侧均正常 EOS 结束，原文最终分别明确给出 boxed 107 和 boxed 115。'
               '规则抽取与原文一致；107 等于冻结参考答案，115 不等于参考答案。'
               '这是完整解答的答案错误，不是格式、截断或运行失败。'
               '本复核只核对输出和评分对应关系，不另行裁定全部证明步骤。',
    output_sha256={v: hashlib.sha256(p.read_bytes()).hexdigest() for v, p in paths.items()},
    original_output_excerpts={v: json.loads(p.read_bytes())['raw_output'][-2400:]
                              for v, p in paths.items()},
    manual_review='both complete output endings, explicit boxed values and frozen reference checked',
))

by_index = {r['index']: r for r in scores['rows']}
changed = {r['index'] for r in scores['rows'] if r['answer_changed']}
if len(review['rows']) != len(changed) or {r['index'] for r in review['rows']} != changed:
    raise AssertionError('manual review must match every formal changed extracted answer exactly')
for inspected in review['rows']:
    formal = by_index[inspected['index']]
    if inspected['id'] != formal['id'] or str(inspected['target']) != str(formal['target']):
        raise AssertionError('review and formal question identity differ')
    for variant in ('official', 'compact'):
        path = evidence / f"formal/{variant}.question{inspected['index']:02}.json"
        if inspected[f'{variant}_extracted'] != formal[variant]['extracted']:
            raise AssertionError('manual review changed frozen-rule extraction')
        if inspected['output_sha256'][variant] != hashlib.sha256(path.read_bytes()).hexdigest():
            raise AssertionError('reviewed output byte identity differs from formal archive')

review['rows'].sort(key=lambda r: r['index'])
review['completed'] = True
review['scope'] = 'all changed extracted answers among all 30 formal paired actual generations'
review['manifest_sha256'] = scores['manifest_sha256']
review['formal_scores_sha256'] = hashlib.sha256((evidence / 'paired-scores.json').read_bytes()).hexdigest()
review['all_reviewed_original_bytes_match_formal_archive'] = True
review['all_extractions_match_formal_scores'] = True
destination = evidence / 'answer-change-review.json'
if destination.exists():
    raise FileExistsError('preserve the first completed review')
destination.write_text(json.dumps(review, ensure_ascii=False, indent=2) + '\n',
                       encoding='utf-8', newline='\n')
print(json.dumps(dict(completed=True, reviewed_changes=len(changed), indices=sorted(changed))))
