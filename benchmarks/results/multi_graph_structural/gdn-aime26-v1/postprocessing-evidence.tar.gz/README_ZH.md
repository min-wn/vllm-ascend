# AIME26 后处理证据

source/ 保存工作区 work/ 下使用的后处理源码，脚本按原目录结构运行；不属于被冻结的模型执行实现。
working-reviews/ 是带有未完成标记的历史工作复核，仅作过程证据。
正式结论以同级 paired-scores.json、continuous-generation-audit.json、answer-change-review.json 和 report.md 为准。
首份 formal-evidence.tar.gz 保存全部原始生成和步进日志；本归档没有启动或重新生成任何题。
